package edu.neu.cloudsimper;

public class LogUnit {
	
	private String split = "  ";

	private long time;
	private String dcName;
	private int requestNum;

	private double usage;
	private double eConsume;
	private double eSupply;
	private double eBattery;
	private double ePrice;
	private double reUsage;

	public long getTime() {
		return time;
	}

	public void setTime(long time) {
		this.time = time;
	}

	public String getDcName() {
		return dcName;
	}

	public void setDcName(String dcName) {
		this.dcName = dcName;
	}

	public int getRequestNum() {
		return requestNum;
	}

	public void setRequestNum(int requestNum) {
		this.requestNum += requestNum;
	}

	public double getUsage() {
		return usage;
	}

	public void setUsage(double usage) {
		this.usage += usage;
	}

	public double getEConsume() {
		return eConsume;
	}

	public void setEConsume(double eConsume) {
		this.eConsume += eConsume;
	}

	public double geteESupply() {
		return eSupply;
	}

	public void setESupply(double eSupply) {
		this.eSupply += eSupply;
	}

	public double getEBattery() {
		return eBattery;
	}

	public void seteBattery(double eBattery) {
		this.eBattery += eBattery;
	}

	public double getReUsage() {
		return reUsage;
	}

	public void setReUsage(double reUsage) {
		this.reUsage += reUsage;
	}

	public double getEPrice() {
		return ePrice;
	}

	public void setEPrice(double ePrice) {
		this.ePrice += ePrice;
	}

	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append(time).append(split).append(dcName).append(split).append(requestNum).append(split).append(usage).append(split)
				.append(eConsume).append(split).append(eSupply).append(split).append(eBattery).append(split).append(ePrice)
				.append(split).append(reUsage);
		return sb.toString();
	}
}

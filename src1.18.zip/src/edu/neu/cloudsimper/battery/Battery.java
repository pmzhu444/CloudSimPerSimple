package edu.neu.cloudsimper.battery;

import java.util.ArrayList;
import java.util.List;

import edu.neu.cloudsimper.Component;
import edu.neu.cloudsimper.Const;
import edu.neu.cloudsimper.Datacenter;
import edu.neu.cloudsimper.LogUnit;
import edu.neu.cloudsimper.SimPerEntity;
import edu.neu.cloudsimper.meta.MetaContainer;
import edu.neu.cloudsimper.meta.MetaDatacenter;
import edu.neu.cloudsimper.meta.MetaManager;

public class Battery extends Component implements SimPerEntity {

	private double capacity;
	private double power;
	private double dod;
	private int lifecyle;

	private double currentPower;
	private double currentCapacity;

	private Datacenter datacenter;

	private Battery(MetaContainer container, int index) {
		this.name = container.getName() + index;
		this.capacity = Integer.parseInt(container.getAttribute(Const.V_CAPACITY));
		this.power = Integer.parseInt(container.getAttribute(Const.V_POWER));
		this.dod = Integer.parseInt(container.getAttribute(Const.V_DOD));
		this.lifecyle = Integer.parseInt(container.getAttribute(Const.V_LIFECYLE));
		this.currentPower = 0;
	}

	public static List<Battery> bulid4Datacenter(MetaDatacenter container) {
		return BatteryBuilder.bulid4Datacenter(container);
	}

	@Override
	public void runTick(int tick, LogUnit unit) {

		if (unit.getEConsume() > unit.geteESupply()) {
			discharge(unit.getEConsume() - unit.geteESupply());
		} else {
			charge(unit.geteESupply() - unit.getEConsume());
		}
		unit.seteBattery(unit.geteESupply() - unit.getEConsume());
		
	}

	public void setDatacenter(Datacenter datacenter) {
		this.datacenter = datacenter;
	}

	private double charge(double power) {
		this.currentPower += power;
		if (currentPower > capacity) {
			double residue = currentPower - capacity;
			currentPower = capacity;
			return residue;
		}
		return 0;
	}

	private double discharge(double needpower) {
		if (currentPower >= needpower) {
			currentPower -= needpower;
			return needpower;
		}
		currentPower = 0;
		return currentPower;
	}

	public double getCurrentPower() {
		return currentPower;
	}

	public double getCurrentCapacity() {
		return currentCapacity;
	}

	private static class BatteryBuilder {
		private static List<Battery> bulid4Datacenter(MetaDatacenter container) {
			List<Battery> batteries = new ArrayList<Battery>();
			List<MetaContainer> metaDcBatteries = container.getBatteries();
			for (MetaContainer metaDcBattery : metaDcBatteries) {
				String name = metaDcBattery.getName();
				int size = metaDcBattery.getSize();
				MetaContainer metaBattery = MetaManager.getBattery(name);
				for (int i = 1; i <= size; i++) {
					batteries.add(new Battery(metaBattery, i));
				}
			}
			return batteries;
		}
	}

}

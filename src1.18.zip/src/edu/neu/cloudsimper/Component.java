package edu.neu.cloudsimper;

public class Component {
	protected String name;

	public Component() {
	}

	public final String getName() {
		return name;
	}
	
	public final void setName(String name) {
		this.name = name;
	}
}

package edu.neu.cloudsimper.energy;

import java.util.Random;

import edu.neu.cloudsimper.CloudSimPer;

public class EnergyPriceFunction extends EnergyPriceAbstract implements EnergyPrice {

	private double p0;
	private double pm;
	private double t;

	public void setP0(double p0) {
		this.p0 = p0;
	}

	public void setPm(double pm) {
		this.pm = pm;
	}

	@Override
	public double calculate(double energy) {
		this.t = getT();		
		double ew = pm / p0;
		double cost = pm * (ew + Math.exp(t));
		return cost * energy;
	}

	private double getT() {
		//TODO
		return 1 + new Random().nextDouble();
	}
}

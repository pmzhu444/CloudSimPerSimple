package edu.neu.cloudsimper.energy;

public interface EnergyPrice {
	
	public double calculate(double energy);
	
}

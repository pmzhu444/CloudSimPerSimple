package edu.neu.cloudsimper.energy;

import edu.neu.cloudsimper.CloudSimPer;

/**
 * @author Jie SONG <songjie@mail.neu.edu.cn>
 */
public abstract class EnergyGeneratorPeriodic extends EnergyGeneratorAbstract implements EnergyGenerator {

	protected int size;
	protected int interval;
	protected double capacity;

	protected double currentPlace;

	/**
	 * the possible max value of one cycle, the min value is 0.
	 */
	protected long cycle;
	protected double[] energies;

	public final void start() {
		this.cycle = interval * size;
		this.energies = new double[size];
		initEnergy();
		for (double energy : energies) {
			this.capacity += energy;
		}
		currentPlace = 0;
	}

	public void setSize(int size) {
		this.size = size;
	}

	public void setInterval(int interval) {
		this.interval = interval;
	}

	public void setCapacity(double capacity) {
		this.capacity = capacity;
	}

	/**
	 * statrPartEnergy:energyStartTime2CycleEnd; loopPartEnergy:energyCycle * loop;
	 * endPartEnergy:energyCycleStart2EndTime
	 */
	@Override
	public double nextEnergy(int duration) {

		double result = 0;
		double nextPlace = 0;
		if (duration > cycle) {
			long loop = duration / cycle;
			result += capacity * loop;
			duration %= cycle;
		}
		if (currentPlace + duration > cycle) {
			nextPlace = (currentPlace + duration) % cycle;
			int currentPlaceRight = (int)Math.floor(currentPlace / interval);
			int nextPlaceRight = (int)Math.floor(currentPlace / interval);
			double oddment = currentPlace % interval;
			result += energies[currentPlaceRight - 1] * (1 - oddment);
			oddment = nextPlace % interval;
			result += energies[nextPlaceRight - 1] * oddment;
			for (int i = currentPlaceRight + 1; i < size -1; i++) {
				result += energies[i];
			}
			for (int i = 0; i < nextPlaceRight -1; i++) {
				result +=energies[i];
			}
		} else {
			nextPlace = currentPlace + duration;
			int currentPlaceRight = (int)Math.floor(currentPlace / interval);
			int nextPlaceRight = (int)Math.floor(currentPlace / interval);
			if (currentPlaceRight == nextPlaceRight) {
				double ratio = (nextPlace - currentPlace) / interval;
				result += energies[currentPlaceRight] * ratio;
			} else {
				double oddment = currentPlace % interval;
				result += energies[currentPlaceRight - 1] * (1 - oddment);
				oddment = nextPlace % interval;
				result += energies[nextPlaceRight - 1] * oddment;
				for (int i = currentPlaceRight + 1; i < nextPlaceRight - 1; i++) {
					result += energies[i];
				}
			}
		}
		currentPlace = nextPlace;
		return result;
	}

	protected abstract void initEnergy();

	private double energyStartTime2CycleEnd(double startTime) {
		return capacity - energyCycleStart2EndTime(startTime);
	}

	private double energyCycleStart2EndTime(double endTime) {
		double endTimeOffset = endTime % cycle;

		double result = 0;
		int endIndex = (int) Math.floor(endTimeOffset / interval);
		double oddment = endTimeOffset % interval;
		for (int i = 0; i < endIndex; i++) {
			result += energies[i];
		}
		result += oddment / interval * energies[endIndex];
		return result;
	}

}

package edu.neu.cloudsimper.energy;

/**
 * @author Jie SONG <songjie@mail.neu.edu.cn>
 */
public class EnergyGeneratorBatteryLinear extends EnergyGeneratorPeriodic implements EnergyGenerator {

	@Override
	protected void initEnergy() {
		double k = capacity / (size - 1);
		for (int i = 0; i < energies.length; i++) {
			energies[i] = k * i;
		}
	}
}

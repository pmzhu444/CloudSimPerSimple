package edu.neu.cloudsimper.request;

public interface RequestRandomization {
	public int randomized(int value);
}

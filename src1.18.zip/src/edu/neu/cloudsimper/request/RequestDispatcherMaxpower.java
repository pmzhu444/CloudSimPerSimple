package edu.neu.cloudsimper.request;

import java.util.List;

public class RequestDispatcherMaxpower extends RequestDispatcherAbstract implements RequestDispatcher{
    @Override
    public void dispatch(List<RequestCore> requests) {

    }
}

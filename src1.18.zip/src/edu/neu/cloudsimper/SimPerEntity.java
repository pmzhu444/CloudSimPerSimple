package edu.neu.cloudsimper;

/**
 * @author Jie SONG <songjie@mail.neu.edu.cn>
 */
public interface SimPerEntity {
	
	public void runTick(int tick, LogUnit unit);
	
}
